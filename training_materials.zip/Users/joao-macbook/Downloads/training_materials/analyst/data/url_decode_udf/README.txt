The 'url-decode-udf' JAR file contains several unrelated, 
simple UDFs. It was compiled and packaged as a convenience
for students who want to experiment with these UDFs but 
are unfamiliar with using git and maven.

The original source code used to build this JAR file can be
found in the original_sources.zip file. The latest version of
the source code can be found on GitHub:

    https://github.com/grisha/hive-udfs

Compilation instructions are documented in the README.md file. 

