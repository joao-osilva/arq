-- Example: Creating a Partitioned Table
CREATE EXTERNAL TABLE customers_by_state (
    cust_id INT,
    fname STRING,
    lname STRING,
    address STRING,
    city STRING,
    zipcode STRING) 
  PARTITIONED BY (state STRING)
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
  LOCATION '/dualcore/customers_by_state';



-- Example: Dynamic Partitioning
SET hive.exec.dynamic.partition.mode=nonstrict;

INSERT OVERWRITE TABLE customers_by_state 
  PARTITION(state) 
  SELECT cust_id, fname, lname, address, 
    city, zipcode, state FROM customers;


-- Example: Static Partitioning
ALTER TABLE customers_by_state ADD PARTITION (state='NY');

INSERT OVERWRITE TABLE customers_by_state 
  PARTITION(state='NY') 
  SELECT cust_id, fname, lname, address, 
    city, zipcode FROM customers WHERE state='NY';


-- Example: Static Partitioning: Partition Calls by Day 
CREATE TABLE call_logs (
    call_time STRING,
    phone STRING,
    event_type STRING,
    details STRING)
  PARTITIONED BY (call_date STRING)
  ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';

ALTER TABLE call_logs 
  ADD PARTITION (call_date='2016-10-01');

LOAD DATA INPATH 'call-20161001.log'
  INTO TABLE call_logs
  PARTITION(call_date='2016-10-01');

LOAD DATA INPATH 'call-20161001.log'
  OVERWRITE INTO TABLE call_logs 
  PARTITION(call_date='2016-10-01');


-- Example: Viewing, Adding, and Removing Partitions
SHOW PARTITIONS call_logs;
ALTER TABLE call_logs ADD PARTITION (call_date='2016-06-05');
ALTER TABLE call_logs DROP PARTITION (call_date='2016-06-05');


-- Example: Using Avro File Format
CREATE TABLE order_details_avro (order_id INT, prod_id INT)
  STORED AS AVRO;

CREATE TABLE order_details_avro
  STORED AS AVRO
  TBLPROPERTIES ('avro.schema.url'=
    'hdfs://localhost/dualcore/order_details.avsc');

CREATE TABLE order_details_avro
  STORED AS AVRO
  TBLPROPERTIES ('avro.schema.literal'=
    '{"name": "order_details",
      "type": "record",
      "fields": [
          {"name": "order_id", "type": "int"},
          {"name": "prod_id", "type": "int"}
        ]}');

-- Example: Using Parquet File Format
CREATE TABLE order_details_parquet (
    order_id INT,
    prod_id INT)
  STORED AS PARQUET;

INSERT OVERWRITE TABLE order_details_parquet 
  SELECT * FROM order_details;


-- Example: LIKE PARQUET in Impala
-- (Impala only)
CREATE EXTERNAL TABLE ad_data
  LIKE PARQUET '/dualcore/ad_data/datafile1.parquet'
  STORED AS PARQUET 
  LOCATION '/dualcore/ad_data/';
