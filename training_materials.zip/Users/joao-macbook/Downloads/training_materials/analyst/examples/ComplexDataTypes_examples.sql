-- Impala only

-- Example: ARRAY
SELECT item, pos
  FROM cust_phones_parquet.phones;

SELECT name, phones.item AS phone
  FROM cust_phones_parquet, cust_phones_parquet.phones;


-- Example: MAP
SELECT key, value
  FROM cust_phones_map_parquet.phones;

SELECT name, phones.value AS home
  FROM cust_phones_map_parquet, cust_phones_map_parquet.phones
  WHERE phones.key = 'home';


-- Example: STRUCT
SELECT name, address.state, address.zipcode
  FROM cust_addr_parquet;
