-- Example: Exploring Databases and Tables
SHOW DATABASES;
DESCRIBE DATABASE default;
SHOW TABLES;
SHOW TABLES IN accounting;
USE accounting;
SHOW TABLES;
USE default;
DESCRIBE orders;


-- Example: Syntax Basics
SELECT cust_id, fname, lname FROM customers WHERE zipcode='60601';
SELECT cust_id, fname, lname FROM customers; 
SELECT * FROM customers;
SELECT DISTINCT zipcode FROM customers; 


-- Example: Sorting Query Results
SELECT brand, name, price FROM products ORDER BY price DESC;


-- Limiting Query Results
SELECT brand, name, price FROM products LIMIT 10;
SELECT brand, name, price FROM products ORDER BY price DESC LIMIT 10;


-- Example: Using a WHERE Clause to Filter Results
SELECT * FROM orders WHERE order_id=1287;
SELECT * FROM customers WHERE state IN ('CA', 'OR', 'WA', 'NV', 'AZ');
SELECT * FROM customers WHERE fname LIKE 'Ann%' AND (city='Seattle' OR city='Portland');


-- Example: Table Aliases
SELECT o.order_date, c.fname, c.lname 
  FROM customers c JOIN orders AS o 
    ON (c.cust_id = o.cust_id) 
  WHERE c.zipcode='94306'; 


-- Example: Combining Query Results with a Union
SELECT cust_id, fname, lname
    FROM customers
    WHERE state='NY'
  UNION ALL 
  SELECT cust_id, fname, lname
    FROM customers
    WHERE zipcode LIKE '073%'


-- Example: Subqueries in the FROM Clause
SELECT prod_id, brand, name 
  FROM (SELECT *
          FROM products
          WHERE (price - cost) / price > 0.65
          ORDER BY price DESC
          LIMIT 10) high_profits
  WHERE price > 1000
  ORDER BY brand, name;


-- Example: Subqueries in the WHERE Clause
SELECT cust_id, fname, lname
  FROM customers c
  WHERE state = 'NY'
    AND c.cust_id IN (SELECT cust_id
                        FROM orders
                        WHERE order_id > 6650000);
