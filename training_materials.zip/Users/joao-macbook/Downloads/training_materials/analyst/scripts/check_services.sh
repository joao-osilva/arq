#!/bin/bash 

# Script to check that all services required for the Data Analyst course are running

verify_service_running() {
  SVC_NAME=$1
  
  if [ -z "$SVC_NAME" ]; then
    echo '### FATAL: verify_service_running invoked incorrectly ###'
    exit 999
  fi

  /sbin/service "$SVC_NAME" status 2> /dev/null | egrep '^running$|is running' > /dev/null
  if [ $? -ne 0 ]; then
    echo ""
    echo "***************************************************"
    echo "* ERROR: The catchup script has failed!           *"
    echo "* One or more required services are not running.  *"
    echo "* To fix this, run the restart services script:   *"
    echo "*                                                 *"
    echo "*        \$ADIR/scripts/restart_services.sh        *"
    echo "*                                                 *"
    echo "* Then run the catchup script again.              *"
    echo "***************************************************"
    echo ""
    exit 1
  fi
}

verify_service_running zookeeper-server
verify_service_running hadoop-yarn-resourcemanager
verify_service_running hadoop-yarn-nodemanager
verify_service_running hadoop-hdfs-datanode
verify_service_running hadoop-hdfs-namenode
verify_service_running hadoop-mapreduce-historyserver
verify_service_running spark-history-server
verify_service_running mysqld
verify_service_running hive-metastore
verify_service_running hive-server2
verify_service_running impala-state-store
verify_service_running impala-catalog
verify_service_running impala-server
verify_service_running hue

exit 0
