#!/bin/bash 

# Script to kill Spark executors on YARN

WARNING_MSG=0
NO_SESSIONS_MSG=1

if [ "$1" == "WARN" ]; then
  WARNING_MSG=1
  NO_SESSIONS_MSG=0
elif [ "$1" == "QUIET" ]; then
  NO_SESSIONS_MSG=0
fi

APP_IDS=
NUM_SPARK_APPS=0
YARN_ALIVE=$(/sbin/service hadoop-yarn-resourcemanager status 2> /dev/null)
RUNNING_REGEX="^running$|is running"
if [[ $YARN_ALIVE =~ $RUNNING_REGEX ]]; then
  APP_IDS=$(yarn application -list -appTypes SPARK 2>/dev/null | grep -P '^application_[\w]+' -o)
  if [ `echo "$APP_IDS" | wc -m` -gt 1 ]; then
    NUM_SPARK_APPS=$(echo "$APP_IDS" | wc -l)
  fi
fi

if [ $NUM_SPARK_APPS -gt 0 ]; then
  echo "$APP_IDS" | while read -r APP_ID; do
    yarn application -kill $APP_ID >/dev/null 2>&1
  done
  if [ $WARNING_MSG -eq 1 ]; then
    echo ""
    echo "***************************************************************************"
    echo "* WARNING: This script has shut down active Spark sessions.               *"
    echo "* This will cause any active Hive on Spark sessions to fail.              *"
    echo "* To resolve this, issue the following command in any open Hive sessions: *"
    echo "*                                                                         *"
    echo "*                      SET hive.execution.engine=mr;                      *"
    echo "*                                                                         *"
    echo "***************************************************************************"
    echo ""
  else
    echo ""
    echo "All Spark executors have been shut down."
    echo ""
  fi
else
  if [ $NO_SESSIONS_MSG -eq 1 ]; then
    echo ""
    echo "There are no active Spark sessions."
    echo ""
  fi
fi
