#!/bin/bash

# This script will advance the state of the VM as if the
# exercise specified on the command line (and all those 
# before it) had been completed. For example, invoking 
# this script as:
#
#   $ advance_labs.sh lab4
#
# Will prepare you to begin work on exercise 5, meaning 
# that the state of the VM will be exactly the same as if 
# exercise 4 (as well as exercises 3, 2, and 1) had been
# manually completed.
#
# BEWARE: In all invocations, this script will first run
#         a 'cleanup' step which removes data in HDFS and
#         the local filesystem in order to simulate the
#         original state of the VM. 
#

ADIR=/home/training/training_materials/analyst

# ensure we run any scripts from a writable local directory, 
# which needs to also not conflict with anything
RUNDIR=/tmp/adht/labscripts/$RANDOM$$
mkdir -p $RUNDIR
cd $RUNDIR


cleanup() {
    echo "Cleaning up your system"

    sudo -u hdfs hdfs dfs -rm -skipTrash -r -f /dualcore/* \
         /user/training/empcounts \
         /user/training/empcounts_java \
         /user/training/demodata \
         /user/training/demoreport \
         /user/hive/warehouse/ratings \
         /user/hive/warehouse/checkout_sessions \
         /user/hive/warehouse/cart_items \
         /user/hive/warehouse/cart_orders \
         /user/hive/warehouse/cart_zipcodes \
         /user/hive/warehouse/cart_shipping \
         /user/*/.sparkStaging >/dev/null 2>&1

    rm -f $ADIR/exercises/pig_etl/sample1.txt
    rm -f $ADIR/exercises/pig_etl/sample2.txt

    # Instead of executing each command in a separate Hive/Impala
    # session, it's much faster to run them all in one.

    # Note that the customers, order_details, orders, and
    # products tables are dropped and recreated here, in case the
    # student has altered or dropped them, even though those
    # tables are not created in the exercises.
    
TMP_SQL=tmp.sql
cat << __END_OF_SQL__ > $TMP_SQL

USE default;
DROP TABLE IF EXISTS ads;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS cart_orders;
DROP TABLE IF EXISTS cart_shipping;
DROP TABLE IF EXISTS cart_zipcodes;
DROP TABLE IF EXISTS checkout_sessions;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS latlon;
DROP TABLE IF EXISTS loyalty_program;
DROP TABLE IF EXISTS loyalty_program_parquet;
DROP TABLE IF EXISTS rating_summary;
DROP TABLE IF EXISTS ratings;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS vendors;
DROP TABLE IF EXISTS web_logs;
DROP FUNCTION IF EXISTS calc_shipping_cost;

__END_OF_SQL__

    cat $ADIR/scripts/create_tables.hql >> $TMP_SQL

    beeline -u jdbc:hive2://localhost:10000 --silent=true -f $TMP_SQL >/dev/null 2>&1
    rm $TMP_SQL

    # Remove subdirectories of /dualcore (fix for CUR-4465)
    sudo -u hdfs hdfs dfs -rm -skipTrash -r /dualcore/* >/dev/null 2>&1
}

lab1() {
    echo "* Advancing to Data Ingest with Hadoop Tools exercise"
 
    # running the actual Sqoop import is too slow, 
    # so we use static data from a previous import.
    hdfs dfs -mkdir /dualcore/employees
    hdfs dfs -put $ADIR/scripts/static_data/employees/part* /dualcore/employees >/dev/null 2>&1

    hdfs dfs -mkdir /dualcore/customers
    hdfs dfs -put $ADIR/scripts/static_data/customers/part* /dualcore/customers >/dev/null 2>&1

    hdfs dfs -mkdir /dualcore/products
    hdfs dfs -put $ADIR/scripts/static_data/products/part* /dualcore/products >/dev/null 2>&1

    hdfs dfs -mkdir /dualcore/orders
    hdfs dfs -put $ADIR/scripts/static_data/orders/part* /dualcore/orders >/dev/null 2>&1

    hdfs dfs -mkdir /dualcore/order_details
    hdfs dfs -put $ADIR/scripts/static_data/order_details/part* /dualcore/order_details >/dev/null 2>&1
}

lab2() {
    # exercise dir: $ADIR/exercises/pig_etl
    echo "* Advancing to Using Pig for ETL Processing exercise"

    hdfs dfs -put $ADIR/data/ad_data1.txt /dualcore >/dev/null 2>&1
    hdfs dfs -put $ADIR/scripts/static_data/ad_data1 /dualcore >/dev/null 2>&1

    hdfs dfs -put $ADIR/data/ad_data2.txt /dualcore >/dev/null 2>&1
    hdfs dfs -put $ADIR/scripts/static_data/ad_data2 /dualcore >/dev/null 2>&1
}

lab3() {
    # exercise dir: $ADIR/exercises/analyze_ads
    echo "* Advancing to Analyzing Ad Campaign Data with Pig exercise"
    # lab 3 doesn't create any data reused later
}

lab4() {
    # exercise dir: $ADIR/exercises/disparate_datasets
    echo "* Advancing to Analyzing Disparate Data Sets with Pig exercise"
    # lab 4 doesn't create any data reused later
}

lab5() {
    # exercise dir: none
    echo "* Advancing to Running Queries from the Shell, Scripts, and Hue exercise"
    # lab 5 doesn't create any data reused later
    
    impala-shell --quiet -q "INVALIDATE METADATA" >/dev/null 2>&1
}

lab6() {
    # exercise dir: $ADIR/exercises/data_mgmt
    echo "* Advancing to Data Management exercise"

    # NOTE: the suppliers table is not used in
    # subsequent labs, so creation is commented
    # out here so the script will run faster.
      # sqoop import \
      #   --connect jdbc:mysql://localhost/dualcore \
      #   --username training --password training \
      #   --fields-terminated-by '\t' \
      #   --table suppliers \
      #   --hive-import
   
    impala-shell --quiet -f $ADIR/exercises/data_mgmt/solution/create_employees_table.sql >/dev/null 2>&1

    # set up ratings table
    hdfs dfs -mkdir -p /user/hive/warehouse/ratings
    hdfs dfs -put $ADIR/data/ratings_2012.txt /user/hive/warehouse/ratings/ratings_2012.txt >/dev/null 2>&1
    hdfs dfs -put $ADIR/data/ratings_2013.txt /user/hive/warehouse/ratings/ratings_2013.txt >/dev/null 2>&1
    impala-shell --quiet -f $ADIR/exercises/data_mgmt/solution/create_ratings_table.sql >/dev/null 2>&1
    
    impala-shell --quiet -q "INVALIDATE METADATA" >/dev/null 2>&1
    
}

lab7() {
    echo "* Advancing to Data Storage and Performance exercise"
    impala-shell --quiet -f $ADIR/exercises/data_storage/solution/create_ads_table.sql >/dev/null 2>&1
    impala-shell --quiet -f $ADIR/exercises/data_storage/solution/load_ad_data.sql >/dev/null 2>&1
    
    # File Format bonus (not required for subsequent exercises)
    hdfs dfs -put $ADIR/data/latlon /dualcore/ >/dev/null 2>&1
    impala-shell --quiet -f $ADIR/exercises/data_storage/bonus_01/solution/create_latlon_table.sql >/dev/null 2>&1
    
}

lab8() {
    echo "* Advancing to Relational Data Analysis exercise"
    # Nothing created that is used later in this course
}


lab9() {
    echo "* Advancing to Complex Data with Hive and Impala exercise"
    
    # set up loyalty program tables
    hdfs dfs -mkdir -p /dualcore/loyalty_program
    hdfs dfs -put $ADIR/data/loyalty_data.txt /dualcore/loyalty_program/ >/dev/null 2>&1
    beeline -u jdbc:hive2://localhost:10000 --silent=true -f $ADIR/exercises/complex_data/solution/loyalty_program_table.hql >/dev/null 2>&1
    beeline -u jdbc:hive2://localhost:10000 --silent=true -f $ADIR/exercises/complex_data/solution/loyalty_program_parquet_table.hql >/dev/null 2>&1
        
    impala-shell --quiet -q "INVALIDATE METADATA" >/dev/null 2>&1
}

lab10() {
    echo "* Advancing to Analyzing Text with Hive exercise"

    # set up weblogs table
    hdfs dfs -mkdir -p /dualcore/web_logs
    hdfs dfs -put $ADIR/data/access.log /dualcore/web_logs >/dev/null 2>&1
    beeline -u jdbc:hive2://localhost:10000 --silent=true -f $ADIR/exercises/text_analysis/create_web_logs.hql >/dev/null 2>&1

    impala-shell --quiet -q "INVALIDATE METADATA" >/dev/null 2>&1
}

lab11() {
    echo "* Advancing to Hive Optimization exercise"
    # Nothing created that is used later in this course
}

lab12() {
    echo "* Advancing to Impala Optimization exercise"
    # Nothing created that is used later in this course
}


lab13() {
    echo "* Advancing to Data Transformation with Hive exercise"
    cd $ADIR/exercises/transform

   hdfs dfs -put $ADIR/exercises/transform/ipgeolocator.py /dualcore/ >/dev/null 2>&1
   hdfs dfs -put $ADIR/exercises/transform/geolocation_udf.jar /dualcore/ >/dev/null 2>&1

    # run all scripts in one Hive session for better performance
    MEGA_SCRIPT=$RUNDIR/mega.hql

    cat create_checkout_sessions.hql >> $MEGA_SCRIPT
    cat create_cart_zipcodes.hql >> $MEGA_SCRIPT
    cat solution/create_cart_items.hql >> $MEGA_SCRIPT
    cat create_cart_orders.hql >> $MEGA_SCRIPT
    cat create_function.hql >> $MEGA_SCRIPT
    cat create_cart_shipping.hql >> $MEGA_SCRIPT

    beeline -u jdbc:hive2://localhost:10000 --silent=true -f $MEGA_SCRIPT >/dev/null 2>&1

    rm -f $MEGA_SCRIPT
}

lab14() {
    echo "* Advancing to Analyzing Abandoned Carts exercise"
    # lab 14 doesn't create any data reused later

    impala-shell --quiet -q "INVALIDATE METADATA" >/dev/null 2>&1
}

case "$1" in
        
    hive)
        # undocumented feature for custom courses
        # advances to first Hive/Impala lab
        cleanup
        lab1
        lab2
        lab3
        lab4
        ;;
            
    pig)
        # undocumented feature for custom courses
        # advances to first Pig-specific lab
        cleanup
        lab1
        ;;
        
    cleanup)
        cleanup
        ;;

    lab1)
        cleanup
        lab1
        ;;

    lab2)
        cleanup
        lab1
        lab2
        ;;

    lab3)
        cleanup
        lab1
        lab2
        lab3
        ;;

   lab4)
        cleanup
        lab1
        lab2
        lab3
        lab4
        ;;

        
    lab5)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        ;;

   lab6)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        ;;

    lab7)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        ;;

    lab8)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        lab8
       ;;

    lab9)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        lab8
        lab9
        ;;

    lab10)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        lab8
        lab9
        lab10
        ;;
        
    lab11)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        lab8
        lab9
        lab10
        lab11
        ;;
        
    lab12)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        lab8
        lab9
        lab10
        lab11
        lab12
        ;;
        
    lab13)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        lab8
        lab9
        lab10
        lab11
        lab12
        lab13
        ;;
        
    lab14)
        cleanup
        lab1
        lab2
        lab3
        lab4
        lab5
        lab6
        lab7
        lab8
        lab9
        lab10
        lab11
        lab12
        lab13
        lab14
        ;;
        
    *)
        echo $"Usage: $0 {lab1|lab2|lab3|lab4|lab5|lab6|lab7|lab8|lab9|lab10|lab11|lab12|lab13|lab14}"
        exit 1

esac

