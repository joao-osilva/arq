EXPLAIN SELECT * FROM products;

COMPUTE STATS products;

COMPUTE STATS order_details;

EXPLAIN SELECT brand, name, COUNT(p.prod_id) AS sold 
  FROM products p
    JOIN order_details d
      ON (p.prod_id = d.prod_id)
  GROUP BY brand, name, p.prod_id
  ORDER BY sold DESC
  LIMIT 3;

EXPLAIN SELECT campaign_id, SUM(cpc) 
  FROM ads 
  WHERE was_clicked=1 
  GROUP BY campaign_id 
  ORDER BY campaign_id;

COMPUTE STATS ads;

EXPLAIN SELECT campaign_id, SUM(cpc) 
  FROM ads 
  WHERE was_clicked=1 
  GROUP BY campaign_id 
  ORDER BY campaign_id;

EXPLAIN SELECT campaign_id, SUM(cpc) 
  FROM ads 
  WHERE network=2 
  GROUP BY campaign_id 
  ORDER BY campaign_id;
