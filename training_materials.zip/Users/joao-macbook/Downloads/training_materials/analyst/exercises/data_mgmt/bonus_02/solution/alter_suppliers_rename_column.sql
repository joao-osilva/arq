ALTER TABLE suppliers CHANGE company name STRING;
