ALTER TABLE suppliers RENAME TO vendors;
