SELECT job_title, COUNT(*) AS num
    FROM employees 
    GROUP BY job_title 
    ORDER BY num DESC
    LIMIT 3;
