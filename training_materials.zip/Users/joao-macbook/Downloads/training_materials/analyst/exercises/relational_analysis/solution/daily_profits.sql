SELECT to_date(order_date) as o_date, SUM(price) AS revenue, SUM(price - cost) as profit
  FROM products p
    JOIN order_details d
      ON (p.prod_id = d.prod_id)
    JOIN orders o
      ON (d.order_id = o.order_id)
  GROUP BY to_date(order_date)
  ORDER BY o_date;
