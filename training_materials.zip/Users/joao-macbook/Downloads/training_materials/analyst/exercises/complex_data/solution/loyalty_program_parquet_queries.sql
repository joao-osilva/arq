
--  Returns the unique key values in the MAP column phone
SELECT DISTINCT(phone.key) FROM loyalty_program_parquet.phone;

-- Returns counts of phone numbers by type
SELECT phone.key, COUNT(phone.value) FROM loyalty_program_parquet.phone GROUP BY phone.key;

-- Returns the number of orders in the ARRAY column order_ids
SELECT COUNT(order_ids.item) FROM loyalty_program_parquet.order_ids;

-- Returns the first order ID for each customer
SELECT order_ids.item FROM loyalty_program_parquet.order_ids WHERE order_ids.pos = 0;

-- Returns the number of customers having 30 or more orders
SELECT COUNT(order_ids.item) FROM loyalty_program_parquet.order_ids WHERE order_ids.pos = 29;
