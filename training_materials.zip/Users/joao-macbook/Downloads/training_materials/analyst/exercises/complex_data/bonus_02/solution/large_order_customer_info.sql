SELECT cust_id, fname, lname, phone.value, phone.key
  FROM loyalty_program_parquet, loyalty_program_parquet.phone
  WHERE order_value.avg > 90000;
