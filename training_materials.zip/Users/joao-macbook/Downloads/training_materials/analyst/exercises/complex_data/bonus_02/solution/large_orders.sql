SELECT cust_id, order_ids.item
  FROM loyalty_program_parquet, loyalty_program_parquet.order_ids
  WHERE order_value.avg > 90000;
