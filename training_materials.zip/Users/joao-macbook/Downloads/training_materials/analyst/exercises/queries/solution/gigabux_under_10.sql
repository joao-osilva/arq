SELECT * 
  FROM products 
  WHERE brand='Gigabux' AND price < 1000;