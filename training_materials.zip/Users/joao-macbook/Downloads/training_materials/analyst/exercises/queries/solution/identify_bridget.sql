SELECT *
  FROM customers 
 WHERE fname LIKE 'Bridg%'
   AND city = 'Kansas City';
