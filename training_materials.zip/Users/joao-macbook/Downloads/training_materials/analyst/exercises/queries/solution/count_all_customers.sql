SELECT COUNT(DISTINCT cust_id) AS total FROM customers;
