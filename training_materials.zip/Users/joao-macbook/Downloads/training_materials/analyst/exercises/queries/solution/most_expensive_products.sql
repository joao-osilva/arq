SELECT * 
  FROM products 
  ORDER BY price DESC
  LIMIT 3;