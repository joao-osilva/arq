SELECT steps_completed, AVG(shipping_cost) AS avg_ship_cost
   FROM cart_shipping  
   WHERE steps_completed IN (2,4)
   GROUP BY steps_completed;
