SELECT SUM(total_price - total_cost - shipping_cost)
      AS potential_profit 
   FROM cart_shipping
   WHERE total_price >= 50000;
